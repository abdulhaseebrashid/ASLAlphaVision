from django.shortcuts import render
from django.core.files.storage import FileSystemStorage
from django.http import JsonResponse
import torch
import torch.nn as nn
from torchvision import transforms
from PIL import Image
import os
from django.conf import settings
from django.views.decorators.csrf import csrf_exempt


class CompressedCNN(nn.Module):
    def __init__(self, num_classes):
        super(CompressedCNN, self).__init__()
        
        # Initial convolution block with fewer filters
        self.conv1 = nn.Sequential(
            nn.Conv2d(3, 32, kernel_size=3, padding=1),  # Reduced from 64 to 32
            nn.BatchNorm2d(32),
            nn.ReLU(inplace=True)
        )
        
        # Deep feature extraction blocks with reduced filters
        self.features = nn.Sequential(
            self._make_block(32, 64),    # Reduced from 64->128 to 32->64
            self._make_block(64, 128),   # Reduced from 128->256 to 64->128
            self._make_block(128, 256),  # Reduced from 256->512 to 128->256
            self._make_block(256, 256)   # Reduced from 512->512 to 256->256
        )
        
        # Global Average Pooling
        self.global_pool = nn.AdaptiveAvgPool2d(1)
        
        # Classifier with reduced neurons
        self.classifier = nn.Sequential(
            nn.Linear(256, 512),  # Reduced from 512->1024 to 256->512
            nn.ReLU(inplace=True),
            nn.Dropout(0.5),
            nn.Linear(512, 256),  # Reduced from 1024->512 to 512->256
            nn.ReLU(inplace=True),
            nn.Dropout(0.3),
            nn.Linear(256, num_classes)  # Reduced from 512->num_classes to 256->num_classes
        )
    
    def _make_block(self, in_channels, out_channels):
        return nn.Sequential(
            nn.Conv2d(in_channels, out_channels, 3, padding=1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_channels, out_channels, 3, padding=1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(2)
        )
    
    def forward(self, x):
        x = self.conv1(x)
        x = self.features(x)
        x = self.global_pool(x)
        x = x.view(x.size(0), -1)
        x = self.classifier(x)
        return x

# Initialize model and settings
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model_path = os.path.join(settings.BASE_DIR, "models", "90%TrainedModel_compressed.pth")

# Ensure model directory exists
os.makedirs(os.path.dirname(model_path), exist_ok=True)

# Create model instance
model = CompressedCNN(num_classes=2)

# Load the model
if os.path.exists(model_path):
    try:
        # Create a quantized version of the model as in your training code
        quantized_model = torch.quantization.quantize_dynamic(
            model, {nn.Linear, nn.Conv2d}, dtype=torch.qint8
        )
        
        # Load the state dict directly - since your training code saves just the state_dict
        state_dict = torch.load(model_path, map_location=device)
        quantized_model.load_state_dict(state_dict)
        
        # Use the quantized model for inference
        model = quantized_model
        model = model.to(device)
        model.eval()
        print("Model loaded successfully!")
    except Exception as e:
        print(f"Error loading model: {str(e)}")
else:
    print(f"Warning: Model file not found at {model_path}")

class_labels = {0: "Laptop", 1: "Smartphone"}  # Swapped the labels

# Match the preprocessing exactly with training
preprocess = transforms.Compose([
    transforms.Resize(256),
    transforms.CenterCrop(224),
    transforms.ToTensor(),
    transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
])

def index(request):
    return render(request, 'index.html', {'title': 'Image Classifier'})


def predictImage(request):
    context = {'title': 'Image Classifier'}
    
    if request.method == 'POST' and request.FILES.getlist('filePath'):
        try:
            results = []
            files = request.FILES.getlist('filePath')
            fs = FileSystemStorage()
            
            for file_obj in files:
                # Validate file type
                if not file_obj.name.lower().endswith(('.png', '.jpg', '.jpeg', 'webp')):
                    context['error'] = 'Please upload only image files (PNG, JPG, JPEG, WEBP)'
                    continue
                
                # Save file
                filename = fs.save(file_obj.name, file_obj)
                file_url = fs.url(filename)
                file_path = os.path.join(settings.MEDIA_ROOT, filename)
                
                # Process image and predict
                img = Image.open(file_path).convert("RGB")
                input_tensor = preprocess(img).unsqueeze(0).to(device)
                
                with torch.no_grad():
                    output = model(input_tensor)
                    probabilities = torch.nn.functional.softmax(output[0], dim=0)
                    predicted_class = torch.argmax(probabilities)
                    predicted_label = class_labels[predicted_class.item()]
                    confidence = probabilities[predicted_class].item() * 100
                    
                    results.append({
                        'filePathName': file_url,
                        'predictedLabel': predicted_label,
                        'confidence': f'{confidence:.2f}%'
                    })
            
            context.update({
                'results': results,
                'success': True
            })
                
        except Exception as e:
            context['error'] = f'Error processing image: {str(e)}'
    
    return render(request, 'index.html', context)


@csrf_exempt
def predict_api(request):
    if request.method != 'POST':
        return JsonResponse({'error': 'Only POST requests are allowed'}, status=405)
    
    if not request.FILES:
        return JsonResponse({'error': 'No files uploaded'}, status=400)
    
    results = []
    try:
        fs = FileSystemStorage()
        
        # Iterate through all uploaded files
        for file_key in request.FILES:
            file_obj = request.FILES[file_key]
            
            # Validate file type
            if not file_obj.name.lower().endswith(('.png', '.jpg', '.jpeg', 'webp')):
                results.append({
                    'filename': file_obj.name,
                    'error': 'Invalid file type'
                })
                continue
            
            try:
                # Save file
                filename = fs.save(file_obj.name, file_obj)
                file_path = os.path.join(settings.MEDIA_ROOT, filename)
                
                # Process image
                img = Image.open(file_path).convert("RGB")
                input_tensor = preprocess(img).unsqueeze(0).to(device)
                
                # Predict
                with torch.no_grad():
                    output = model(input_tensor)
                    probabilities = torch.nn.functional.softmax(output[0], dim=0)
                    predicted_class = torch.argmax(probabilities)
                    predicted_label = class_labels[predicted_class.item()]
                    confidence = probabilities[predicted_class].item() * 100
                    
                    # Add prediction result
                    results.append({
                        'filename': file_obj.name,
                        'predictedLabel': predicted_label,
                        'confidence': f'{confidence:.2f}%'
                    })
                
                # Clean up - delete the uploaded file
                fs.delete(filename)
            
            except Exception as file_error:
                results.append({
                    'filename': file_obj.name,
                    'error': str(file_error)
                })
        
        # Return JSON response with all predictions
        return JsonResponse({
            'success': len(results) > 0,
            'results': results
        })
    
    except Exception as e:
        return JsonResponse({
            'success': False,
            'error': str(e)
        }, status=500)



# from django.shortcuts import render
# from django.core.files.storage import FileSystemStorage
# from django.http import JsonResponse
# from PIL import Image
# import os
# from django.conf import settings
# from django.views.decorators.csrf import csrf_exempt

# # Mock class labels
# class_labels = {0: "Smartphone", 1: "Laptop"}

# def index(request):
#     return render(request, 'index.html', {'title': 'Image Classifier'})

# def predictImage(request):
#     context = {'title': 'Image Classifier'}
    
#     if request.method == 'POST' and request.FILES.getlist('filePath'):
#         try:
#             results = []
#             files = request.FILES.getlist('filePath')
#             fs = FileSystemStorage()
            
#             for file_obj in files:
#                 # Validate file type
#                 if not file_obj.name.lower().endswith(('.png', '.jpg', '.jpeg', 'webp')):
#                     context['error'] = 'Please upload only image files (PNG, JPG, JPEG, WEBP)'
#                     continue
                
#                 # Save file
#                 filename = fs.save(file_obj.name, file_obj)
#                 file_url = fs.url(filename)
                
#                 # Mock prediction (alternates between laptop and smartphone)
#                 predicted_class = len(results) % 2  # Alternates between 0 and 1
#                 predicted_label = class_labels[predicted_class]
#                 confidence = 95.5  # Mock confidence value
                
#                 results.append({
#                     'filePathName': file_url,
#                     'predictedLabel': predicted_label,
#                     'confidence': f'{confidence:.2f}%'
#                 })
            
#             context.update({
#                 'results': results,
#                 'success': True
#             })
                
#         except Exception as e:
#             context['error'] = f'Error processing image: {str(e)}'
    
#     return render(request, 'index.html', context)

# @csrf_exempt
# def predict_api(request):
#     if request.method != 'POST':
#         return JsonResponse({'error': 'Only POST requests are allowed'}, status=405)
    
#     if not request.FILES:
#         return JsonResponse({'error': 'No files uploaded'}, status=400)
    
#     results = []
#     try:
#         fs = FileSystemStorage()
        
#         # Iterate through all uploaded files
#         for file_key in request.FILES:
#             file_obj = request.FILES[file_key]
            
#             # Validate file type
#             if not file_obj.name.lower().endswith(('.png', '.jpg', '.jpeg', 'webp')):
#                 results.append({
#                     'filename': file_obj.name,
#                     'error': 'Invalid file type'
#                 })
#                 continue
            
#             try:
#                 # Save file
#                 filename = fs.save(file_obj.name, file_obj)
                
#                 # Mock prediction (alternates between laptop and smartphone)
#                 predicted_class = len(results) % 2  # Alternates between 0 and 1
#                 predicted_label = class_labels[predicted_class]
#                 confidence = 95.5  # Mock confidence value
                
#                 # Add prediction result
#                 results.append({
#                     'filename': file_obj.name,
#                     'predictedLabel': predicted_label,
#                     'confidence': f'{confidence:.2f}%'
#                 })
                
#                 # Clean up - delete the uploaded file
#                 fs.delete(filename)
            
#             except Exception as file_error:
#                 results.append({
#                     'filename': file_obj.name,
#                     'error': str(file_error)
#                 })
        
#         # Return JSON response with all predictions
#         return JsonResponse({
#             'success': len(results) > 0,
#             'results': results
#         })
    
#     except Exception as e:
#         return JsonResponse({
#             'success': False,
#             'error': str(e)
#         }, status=500)



import os
import torch
import torch.nn as nn
import torchvision.transforms as transforms
import torchvision.models as models
from PIL import Image
import json
import base64
import io
from django.shortcuts import render
from django.conf import settings
from django.core.files.storage import FileSystemStorage
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt

# Define the same transforms as in your training script
transform = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
])

# Create the model architecture (same as in your training script)
def create_model(num_classes):
    model = models.resnet50(weights=None)  # No need for pretrained weights as we'll load our own
    
    # Replace the last fully connected layer
    num_ftrs = model.fc.in_features
    model.fc = nn.Sequential(
        nn.Dropout(0.5),
        nn.Linear(num_ftrs, 512),
        nn.ReLU(),
        nn.Dropout(0.3),
        nn.Linear(512, num_classes)
    )
    
    return model

# Load the trained model
def load_model():
    model_path = os.path.join(settings.BASE_DIR, 'models', 'ASL_Sign_model_checkpoint.pth')
    try:
        checkpoint = torch.load(model_path, map_location=torch.device('cpu'))
        num_classes = len(checkpoint['classes'])
        model = create_model(num_classes)
        model.load_state_dict(checkpoint['model_state_dict'])
        model.eval()
        return model, checkpoint['class_to_idx'], checkpoint['classes']
    except Exception as e:
        print(f"Error loading model: {e}")
        return None, None, None

# Initialize the model
model, class_to_idx, classes = load_model()

# Main page view
def index(request):
    return render(request, 'index.html')

# Real-time webcam view
def webcam(request):
    return render(request, 'webcam.html', {'classes': classes})

# Prediction function for web interface
def predictImage(request):
    if request.method == 'POST' and request.FILES['image']:
        # Get the uploaded image
        image_file = request.FILES['image']
        fs = FileSystemStorage()
        filename = fs.save(image_file.name, image_file)
        uploaded_file_path = fs.path(filename)
        
        # Make prediction
        prediction, confidence = predict_asl_sign(uploaded_file_path)
        
        # Delete the uploaded file after prediction
        fs.delete(filename)
        
        return render(request, 'index.html', {
            'prediction': prediction,
            'confidence': confidence,
            'classes': classes
        })
    return render(request, 'index.html')

# API endpoint for predictions
def predict_api(request):
    if request.method == 'POST' and request.FILES['image']:
        # Get the uploaded image
        image_file = request.FILES['image']
        fs = FileSystemStorage()
        filename = fs.save(image_file.name, image_file)
        uploaded_file_path = fs.path(filename)
        
        # Make prediction
        prediction, confidence = predict_asl_sign(uploaded_file_path)
        
        # Delete the uploaded file after prediction
        fs.delete(filename)
        
        return JsonResponse({
            'success': True,
            'prediction': prediction,
            'confidence': confidence,
        })
    return JsonResponse({'success': False, 'error': 'No image provided'})

# Function to predict the ASL sign from an image
def predict_asl_sign(image_path):
    global model, class_to_idx, classes
    
    if model is None:
        model, class_to_idx, classes = load_model()
    
    try:
        # Open and preprocess the image
        img = Image.open(image_path).convert('RGB')
        img_tensor = transform(img).unsqueeze(0)  # Add batch dimension
        
        # Make prediction
        with torch.no_grad():
            outputs = model(img_tensor)
            probabilities = torch.nn.functional.softmax(outputs, dim=1)
            confidence, preds = torch.max(probabilities, 1)
        
        # Get prediction class
        idx = preds.item()
        idx_to_class = {v: k for k, v in class_to_idx.items()}
        prediction = idx_to_class[idx]
        
        return prediction, confidence.item() * 100  # Return confidence as percentage
    except Exception as e:
        print(f"Error during prediction: {e}")
        return "Error", 0

# Real-time webcam prediction endpoint
@csrf_exempt
def predict_frame(request):
    if request.method == 'POST':
        try:
            # Get the frame data from the request
            data = json.loads(request.body)
            frame_data = data.get('frame')
            
            # Decode the base64 image
            image_data = base64.b64decode(frame_data.split(',')[1])
            image = Image.open(io.BytesIO(image_data)).convert('RGB')
            
            # Use the model to predict
            img_tensor = transform(image).unsqueeze(0)
            
            with torch.no_grad():
                outputs = model(img_tensor)
                probabilities = torch.nn.functional.softmax(outputs, dim=1)
                
                # Get top 3 predictions
                top_probs, top_indices = torch.topk(probabilities, 3)
                
                # Convert to list of predictions
                idx_to_class = {v: k for k, v in class_to_idx.items()}
                top_predictions = []
                
                for i in range(3):
                    idx = top_indices[0][i].item()
                    prob = top_probs[0][i].item() * 100
                    if prob > 5:  # Only include predictions with >5% confidence
                        top_predictions.append({
                            'label': idx_to_class[idx],
                            'confidence': prob
                        })
                
                return JsonResponse({
                    'success': True,
                    'predictions': top_predictions
                })
        except Exception as e:
            print(f"Error processing frame: {e}")
            return JsonResponse({'success': False, 'error': str(e)})
    
    return JsonResponse({'success': False, 'error': 'Invalid request method'})
# Add this function to your views.py file
def webcam(request):
    return render(request, 'webcam.html', {'classes': classes})